"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.V0_FEED_MODELS = void 0;
const FeedItem_1 = require("./feed/models/FeedItem");
exports.V0_FEED_MODELS = [FeedItem_1.FeedItem];
//# sourceMappingURL=model.index.js.map